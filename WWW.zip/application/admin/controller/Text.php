<?php  
namespace app\admin\controller;
use think\Session;
use think\Loader;
header("Content-Type:text/html; charset=utf-8");
class Text
{
    public function text(){
        return view();
    }
}
?>